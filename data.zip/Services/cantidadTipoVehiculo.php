

<?php
function get_json_input(){
    $content = file_get_contents("php://input");
    $json = json_decode($content);
    return $json;
}

function insert(){
    $raw_json = get_json_input();
    if ($raw_json==NULL)die ("JSON Parsing obtuvo un error");
        if (!isset($raw_json->FechaInicio)
            || !isset($raw_json->FechaFin)){
            die ("JSON Key obtuvo un error");
        }else{
            //depuracion
            //"DEBUG: " .var_dump($raw_json);
            //acceso
            return $raw_json;
        }
}

$raw_json = insert(); //$raw_json->FechaInicio,'$raw_json->FechaFin'






$sql = "Select count(a.placa) as cantidad , b.nombre from transaccion a inner join vehiculo c on a.placa=c.placa inner join tipo_vehiculo b on b.codigo_tipo_vehiculo=c.codigo_tipo_vehiculo where  fechaEntrada  >= '$raw_json->FechaInicio' and fechasalida <= '$raw_json->FechaFin' Group by b.codigo_tipo_vehiculo";



function connectDB(){

        $server = "localhost";
        $user = "id5291720_4dm1n";
        $pass = "BXJEV8GzWE1i";
        $bd = "id5291720_softparking";

    $conexion = mysqli_connect($server, $user, $pass,$bd);

        if($conexion){
           //echo 'La conexion de la base de datos se ha hecho satisfactoriamente ';
        }else{
            echo 'Ha sucedido un error inexperado en la conexion de la base de datos ';
        }

    return $conexion;
}

function disconnectDB($conexion){

    $close = mysqli_close($conexion);

        if($close){
            //echo 'La desconexion de la base de datos se ha hecho satisfactoriamente';
        }else{
           echo 'Ha sucedido un error inexperado en la desconexion de la base de datos';
        }   

    return $close;
}

function getArraySQL($sql){
    //Creamos la conexión con la función anterior
    $conexion = connectDB();

    //generamos la consulta

        mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

    if(!$result = mysqli_query($conexion, $sql)) die(); //si la conexión cancelar programa

    $rawdata = array(); //creamos un array

    //guardamos en un array multidimensional todos los datos de la consulta
    $i=0;

    
    while($row = mysqli_fetch_array($result)) 
    { 
        
        $Codigo=$row['cantidad'];
        $nombre=$row['nombre'];
        $rawdata[$i] = array('value'=> $Codigo, 'name'=> $nombre);
        $i++;
    }

    disconnectDB($conexion); //desconectamos la base de datos

    return $rawdata; //devolvemos el array
}

        $myArray = getArraySQL($sql);
        echo json_encode($myArray);
?>