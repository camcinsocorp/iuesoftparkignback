<?php
include(Conexion.php);
function get_json_input(){
	$content = file_get_contents("php://input");
	$json = json_decode($content);
	return $json;
}

function insert(){
	$raw_json = get_json_input();
	if ($raw_json==NULL)die ("JSON Parsing obtuvo un error");
		if (!isset($raw_json->codigo)
			|| !isset($raw_json->nombre)
			|| !isset($raw_json->eliminado)){
			die ("JSON Key obtuvo un error");
		}else{
			//depuracion
			"DEBUG: " .var_dump($raw_json);
			//acceso
            return $raw_json;
		}
}

$raw_json = insert();

$link = mysqli_connect("localhost", "id5291720_4dm1n", "BXJEV8GzWE1i", "id5291720_softparking");
 
// // Comprobar la conexicion con el servidor
if($link === false){
   die("ERROR: Could not connect. " . mysqli_connect_error());
 }
 
// // Attempt insert query execution
$sql = "INSERT INTO tipo_persona (codigo_tipo_persona,nombre, eliminado) VALUES ($raw_json->codigo,'$raw_json->nombre',$raw_json->eliminado)";
if(mysqli_query($link, $sql)){
     echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
 }
 
// // Close connection
 mysqli_close($link);
?>