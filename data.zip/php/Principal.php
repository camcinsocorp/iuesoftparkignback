<?php

include("Conexion.php");

$resultados= mysqli_query($conexion,"SELECT * FROM persona");

while($consulta = mysqli_fetch_array($resultados))

{
    
    echo($consulta['cedula']);
echo "<br>";

}

?>