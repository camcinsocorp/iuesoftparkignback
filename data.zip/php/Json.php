<?php

$data = json_decode(file_get_contents('php://input'), true);


  		$server = "localhost";
        $user = "id5291720_4dm1n";
        $pass = "BXJEV8GzWE1i";
        $bd = "id5291720_softparking";

//Creamos la conexión
$conexion = mysqli_connect($server, $user, $pass,$bd) 
or die("Ha sucedido un error inexperado en la conexion de la base de datos");

//generamos la consulta
$sql = 




mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

if(!$result = mysqli_query($conexion, $sql)) die();

$persona = array(); //creamos un array

while($row = mysqli_fetch_array($result)) 
{ 
     $codigo=$row['codigo'];
    $nombre=$row['nombre'];
    
    

    $persona[] = array('codigo'=> $codigo, 'nombre'=> $nombre);

}
    
//desconectamos la base de datos
$close = mysqli_close($conexion) 
or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
  

//Creamos el JSON



echo json_encode($data);



//Si queremos crear un archivo json, sería de esta forma:
/*
$file = 'clientes.json';
file_put_contents($file, $json_string);
*/
?>