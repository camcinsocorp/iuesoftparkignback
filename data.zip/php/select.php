<?php
function get_json_input(){
    $content = file_get_contents("php://input");
    $json = json_decode($content);
    return $json;
}

function insert(){
    $raw_json = get_json_input();
    if ($raw_json==NULL)die ("JSON Parsing obtuvo un error");
        if (!isset($raw_json->codigo)
            || !isset($raw_json->fechaEntrada)){
            die ("JSON Key obtuvo un error");
        }else{
            //depuracion
            "DEBUG: " .var_dump($raw_json);
            //acceso
            return $raw_json;
        }
}

//$raw_json = insert(); //$raw_json->codigo,'$raw_json->nombre'


//$raw_json->codigo

$sql = "SELECT count(codigo_transaccion) as Codigo,fechaEntrada FROM transaccion group by fechaEntrada ";


function connectDB(){

        $server = "localhost";
        $user = "id5291720_4dm1n";
        $pass = "BXJEV8GzWE1i";
        $bd = "id5291720_softparking";

    $conexion = mysqli_connect($server, $user, $pass,$bd);

        if($conexion){
           //echo 'La conexion de la base de datos se ha hecho satisfactoriamente ';
        }else{
            echo 'Ha sucedido un error inexperado en la conexion de la base de datos ';
        }

    return $conexion;
}

function disconnectDB($conexion){

    $close = mysqli_close($conexion);

        if($close){
            //echo 'La desconexion de la base de datos se ha hecho satisfactoriamente';
        }else{
           echo 'Ha sucedido un error inexperado en la desconexion de la base de datos';
        }   

    return $close;
}


        $myArray = getArraySQL($sql);
        echo json_encode($myArray);
        
        
        if(!$result = mysqli_query($conexion, $sql)) die();

$persona = array(); //creamos un array

while($row = mysqli_fetch_array($result)) 
{ 
    $cedula=$row['cedula'];
    $nombre=$row['nombre'];
    $codigo_tipo=$row['codigo_tipo_persona'];
    

    $persona[] = array('cedula'=> $cedula, 'nombre'=> $nombre,'codigo_tipo_persona'=> $codigo_tipo);

}
    
//desconectamos la base de datos
$close = mysqli_close($conexion) 
or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
  

//Creamos el JSON
$json_string = json_encode($persona);
echo $json_string;
?>