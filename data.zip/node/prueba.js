var mysql = require('mysql');
var http = require('http');
var url = require('url');



http.createServer(function (req, res) {
	res.writeHead(200, {'Content-Type': 'text/html'});

	var con = mysql.createConnection({
		host: "localhost",
		user: "id5291720_4admin",
		password: "BXJEV8GzWE1i",
		database: "id5291720_softparking"
	});

	con.connect(function(err) {
		if (err) throw err;
		console.log("Connected!");
		con.query("select * from persona", function (err, result) {
			if (err) throw err;
			if(result.length > 0){
				res.end(result);
			}
		});
	});


}).listen(8080);



